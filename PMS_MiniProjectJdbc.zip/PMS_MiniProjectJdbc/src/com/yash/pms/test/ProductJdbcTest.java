package com.yash.pms.test;

import com.yash.pms.utility.ProductUtility;

public class ProductJdbcTest extends ProductUtility{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String userinput;
		int exit = 0;
		
		
		while (exit == 0){ 
		
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.Search");
			System.out.println("4.Update");
			System.out.println("5.Delete");
			System.out.println("6.Terminate");
			System.out.println("Enter your choice");
		
		 userinput = sc.next();
			switch (userinput) {

			case "Add":
				productServiceImplement.addProduct();
				break;

			case "Display":

				productServiceImplement.displayProduct();

				break;

			case "Search":
				
				productServiceImplement.searchProduct();
				break;

			case "Update":
				
				productServiceImplement.updateProduct();
				break;

			case "Delete":
				
				productServiceImplement.deleteProduct();
				break;
				
			case "Terminate":
				System.out.println("Terminated!!");
				System.exit(0);
				break;

			default:
				break;

			}

			
		}
	}

}
