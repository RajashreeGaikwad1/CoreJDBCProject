package com.yash.pms.serviceImpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.yash.pms.model.Product;
import com.yash.pms.service.ProductService;
import com.yash.pms.utility.ProductUtility;

public class ProductServiceImplement extends ProductUtility  implements ProductService {
	
	@Override
	public void addProduct() {
		int updatedRows = 0;
		System.out.println("**********WELCOME************");
		System.out.println("Insert the product id");
		int productId = sc.nextInt();

		System.out.println("Insert the product Name:");
		String productName = sc1.nextLine();

		System.out.println("Insert the product price:");
		int productPrice = sc.nextInt();

		System.out.println("Insert the product Quantity:");
		int productQuantity = sc.nextInt();

		// c.add(new Product(productId, productName, productPrice, productQuantity));
		try {

			updatedRows = prodDao.insertProduct(new Product(productId, productName, productPrice, productQuantity));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (updatedRows > 0) {
			System.out.println("Product Added Successfully !!");
		}

	}

	@Override
	public void displayProduct() {
		// TODO Auto-generated method stub
		System.out.println("***********************");
		List<Product> c = null;
		try {
			c = prodDao.getAllProducts(0);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!c.isEmpty()) {
			Iterator<Product> i = c.iterator();
			while (i.hasNext()) {
				Product p = i.next();
				System.out.println(p);
			}
		} else {
			System.out.println("Product not added !!");
		}

	}

	@Override
	public void searchProduct() {
		// TODO Auto-generated method stub
		boolean found = false;
		System.out.println("Enter the product Id:");
		int id = sc.nextInt();
		List<Product> c = new ArrayList<>();
		try {
			c = prodDao.getAllProducts(id);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!c.isEmpty()) {
			Iterator<Product> i = c.iterator();
			while (i.hasNext()) {
				Product p = i.next();
				System.out.println(p);
			}
		} else {
			System.out.println("-Product not found !!");
		}

		System.out.println("*******************");

	}

	@Override
	public void updateProduct() {
		// TODO Auto-generated method stub
		boolean found = false;
		System.out.println("please enter the product id for update");
		int id = sc.nextInt();
		List<Product> c = new ArrayList<>();
		System.out.println("insert the prodct name:");
		String productName = sc1.nextLine();

		System.out.println("insert the prodct price:");
		int productPrice = sc.nextInt();

		System.out.println("insert the prodct Quantity:");
		int productQunty = sc.nextInt();

		// li.set(new Product(id, productName, productPrice, productQunty));
		try {
			c = prodDao.updateProduct(new Product(id, productName, productPrice, productQunty));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!c.isEmpty()) {
			System.out.println("Product is updated successfully");
		} else {
			System.out.println("Product not found");
		}
	}

	@Override
	public void deleteProduct() {
		// TODO Auto-generated method stub

		boolean found = false;
		System.out.println("Enter the product id ");
		int id = sc.nextInt();
		//List<Product> c = new ArrayList<>();
		try {
			prodDao.deleteProduct(id);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (!found) {
			System.out.println("product is deleted successfully...!");
		} else {
			System.out.println("product not found");
		}

		System.out.println("******************************");
			
		
		
	}

}
